<?php
 
include_once 'database.php';
 
$conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
 
//CREATE
if (isset($_POST['create'])) {

  try{

    // Process the image that is uploaded by the user
    $target_dir = "images/studentPic/";
    $original_file_name = basename($_FILES["pic"]["name"]);
    $student_id = $_POST['sid'];


    // Construct the new file name using the format "S000001.jpg"
    $new_file_name = $student_id . ".jpg";
    $target_file = $target_dir . $new_file_name;
    $uploadOk = 1;
    $imageFileType = pathinfo($target_file, PATHINFO_EXTENSION);

    if (move_uploaded_file($_FILES["pic"]["tmp_name"], $target_file)) {
        echo "<script>alert('The file " . $new_file_name . " has been uploaded.'); window.location.href='student_profile.php'</script>";
    } else {
        echo "Sorry, there was an error uploading your file.";
    }

    // Now $new_file_name contains the updated file name with the student ID.

    $stmt = $conn->prepare("UPDATE tbl_student SET studentPic = :pic WHERE studentID = :sid");

    $stmt->bindParam(':sid', $sid, PDO::PARAM_STR);
    $stmt->bindParam(':pic', $new_file_name, PDO::PARAM_STR);

    $sid = $_GET['sid'];
    $stmt->execute();
}

  catch(PDOException $e)
  {
    echo "Error: " . $e->getMessage();
  }
}
 

//Update
if (isset($_POST['update'])) {
 
  try {
 
      $stmt = $conn->prepare("UPDATE tbl_student
       SET studentID = :sid,
        studentName = :sname, studentEmail = :semail, 
        studentPhone = :sphone, studentAddress = :saddress, studentGender = :sgender
        WHERE studentID = :oldsid");
     
      $stmt->bindParam(':sid', $sid, PDO::PARAM_STR);
      $stmt->bindParam(':sname', $sname, PDO::PARAM_STR);
      $stmt->bindParam(':semail', $semail, PDO::PARAM_STR);
      
      $stmt->bindParam(':sphone', $sphone, PDO::PARAM_STR);
      $stmt->bindParam(':saddress', $saddress, PDO::PARAM_STR);
      $stmt->bindParam(':sgender', $sgender, PDO::PARAM_STR);
      $stmt->bindParam(':oldsid', $oldsid, PDO::PARAM_STR);
       
    $sid = $_POST['sid'];
    $sname = $_POST['sname'];
    $semail = $_POST['semail'];
    
    $sphone = $_POST['sphone'];
    $saddress = $_POST['saddress'];
    $sgender= $_POST['sgender'];
    $oldsid = $_POST['oldsid'];
     
    $stmt->execute();
 
    header("Location: student_profile.php?edit=" . $sid);
    }
 
  catch(PDOException $e)
  {
      echo "Error: " . $e->getMessage();
  }
}
 

 
//Edit
if (isset($_GET['edit'])) {
 
  try {
 
      $stmt = $conn->prepare("SELECT * FROM tbl_student WHERE studentID = :sid");
     
      $stmt->bindParam(':sid', $sid, PDO::PARAM_STR);
       
    $sid = $_GET['edit'];
     
    $stmt->execute();
 
    $editrow = $stmt->fetch(PDO::FETCH_ASSOC);
    }
 
  catch(PDOException $e)
  {
      echo "Error: " . $e->getMessage();
  }
}
 
  $conn = null;
?>
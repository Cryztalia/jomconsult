<?php
 
$servername = "lrgs.ftsm.ukm.my";
$username = "a188791";
$password = "giantpinkfrog";
$dbname = "a188791";
$conn = mysqli_connect($servername, $username, $password, $dbname);
 
?>